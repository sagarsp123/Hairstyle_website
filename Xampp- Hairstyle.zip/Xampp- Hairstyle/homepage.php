<!DOCTYPE html>

<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Home</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body background="h6.jpg" style="margin: 0px;background-size: cover;">

	<h1 style="background: #512415;padding: 20px; margin: 0px;">
	
	<div class="navbar">
	<a href="homepage.php" style="text-decoration: none">Home</a>
	<a href="aboutpage.php"style="text-decoration: none">About Us</a>

	<div class="dropdown">
	    <button class="dropbtn"> Register
	      <i class="fa fa-caret-down"></i>
	    </button>
	    <div class="dropdown-content">
	      <a href="form-1.php">Register</a>
	      <a href="login.php">Log In</a>
	      
	      
	    </div>
	</div>
	  
 
	<a href="animations.php" style="text-decoration: none">Gallery</a>
	<a href="form-2.php" style="text-decoration: none">Style</a>
	<a href="feedback.php"style="text-decoration: none">Feedback</a>
	<a href="Contact.php"style="text-decoration: none">Contact</a>
	
    <a href="https://www.facebook.com/"><i class="fa fa-facebook" onMouseOver="this.style.color='#0000cc'" onMouseOut="this.style.color='white'" style="color: white;float: right;padding: 15px;"></i></a>

	<a href="https://www.instagram.com/"  ><i class="fa fa-instagram"  onMouseOver="this.style.color='pink'" onMouseOut="this.style.color='white'" style="float:right;color: white; padding: 15px;"></i></a>
	
	<a href="https://www.twitter.com/"><i class="fa fa-twitter" onMouseOver="this.style.color='#1E90FF'" onMouseOut="this.style.color='white'" style="color: white;float: right;padding: 15px;"></i></a>

	
		 
  
	
	</h1><br><br>

	<img   src="h1.jpg" width="300" style="opacity: 0.6s" height="300" align="sleft">		
	<center><h2  style="color: white; font-size: 45px; font-family: sans-serif;">- GENTLEMEN'S -</h2></center>
	<center><h2 style="color:white; font-size: 60px;font-family: sans-Serif;"> HAIR STYLE ON POINT</h2></center>
	<hr style="width: 70%"><br><br><br>

	

	<article style="padding: 20px;color: grey;font-size: 20px">
		<h2 align="center" style="font-size: 60px;color: #FF7F50;font-style: bold;font-family: sans-serif;">OUR STORY</h2>
		<p style="color: white;font-size: 30px;font-family:serif ; background:#daa671;padding: 10px;color: black">
			" I think dress, hairstyle and make-up are the crucial factors in projecting an attractive persona and give one the chance to enhance one's best physical features"<br> -Vivienne Westwood<br><br>In today's competitive world, a proper appearance is important - both in professional and casual life. Our hair is a key component of our appearance. Hence, people of all ages and genders try to style their hair in a way that suits them best. Yet, this opportunity to improve stays locked behind expensive salons and barbershops. <br><br>This is a problem modern technology can solve. Using a database of hairstyles, we characterize each hairstyle into different categories. We three team members strive to create a website than can suggest hairstyles that are just right for you. Each an everu individualycan have their preferences attended to using just a computer screen. From the comfort of your home, you can consider different hairstyles and interesting appearances. Hence, we three students have set out to create such a website for this exciting application.<br><br>

		</p>
			
    </article>
    <hr style="width: 70%"><br>

    <br><br><br><br>

    <div class="box">
    <div class="maincontainer">

    <div class="thecard">

    <div class="thefront">

	<img   src="images/straight.jpg" width="250" style="opacity: 1.5s" height="320" align="left">		
	<div class="bottom">Straight Hair</div>


    </div>

    <div class="theback"><br>Straight Hair

    <div class="centered">Guys with straight hair are<br>truly lucky–almost all the <br>best, stylish men’s hair <br>styles work well with thick,<br> straight hair. </div>

    </div>

    </div>	


    </div>

    <div class="maincontainer">

    <div class="thecard">

    <div class="thefront">

	<img   src="images/curly.jpg" width="250" style="opacity: 1.5s" height="320" align="left">		
	<div class="bottom">Curly Hair</div>


    </div>

    <div class="theback"><br>Curly Hair

    <div class="centered">Most men think that they are<br>fighting a lost battle when<br>styling their curly mane.<br>
 However,we know that when<br>cared for and styled<br>appropriately,curly hair<br>makes for a striking feature.<br> </div>

    </div>

    </div>	


    </div>

    <div class="maincontainer">

    <div class="thecard">

    <div class="thefront">

	<img   src="images/spiky.jpg" width="250" style="opacity: 1.5s" height="320" align="left">		
	<div class="bottom">Spiky Hair</div>


    </div>

    <div class="theback"><br>Spiky Hair

    <div class="centered">Spiky hair has long been a<br> fashionable look for men,<br>and while the rock-hard <br>points of the past are gone,<br> this sharp style remains an<br> excellent option for gents.</div>

    </div>

    </div>	


    </div>
	
    <div class="maincontainer">

    <div class="thecard">

    <div class="thefront">

	<img   src="images/scissor.jpg" width="250" style="opacity: 1.5s" height="320" align="left">		
	<div class="bottom">Scissor cut Hair</div>


    </div>

    <div class="theback"><br>Scissor cut Hair

    <div class="centered"> Hair-cutting shears have<br> specific blade angles ideal<br> for cutting hair. </div>

    </div>

    </div>	


    </div>
    <div class="maincontainer">

    <div class="thecard">

    <div class="thefront">

	<img   src="images/slick.jpg" width="250" style="opacity: 1.5s" height="320" align="left">		
	<div class="bottom">Slick Back Hair</div>


    </div>

    <div class="theback"><br>Slick Back Hair

    <div class="centered"> Want to look formal with<br> long hair?Then the slick back<br> style is for you.<br> Use a wet product like<br> pomade and a comb to<br> pull your hair back,<br> keeping it neat and tidy<br> for any fancy occasion.</div>

    </div>

    </div>	


    </div>
    
    <div class="maincontainer">

    <div class="thecard">

    <div class="thefront">

	<img   src="images/ponytail.jpg" width="250" style="opacity: 1.5s" height="320" align="left">		
	<div class="bottom">Ponytail</div>


    </div>

    <div class="theback"><br>Ponytail

    <div class="centered">Ponytail hairstyles offer a<br> simple and quick<br> alternative to blow drying<br> and styling long hair. </div>

    </div>

    </div>	


    </div>
    
	</div>


    <br><br><br><br>
    <div class="container" align="right" >
		<my style="padding:20px;font-size: 30px;font-family: sans-serif;">About Us </my> <br>

		<br><iframe style="float: right;" width="600" height="300" src="https://www.youtube.com/embed/LDAT9NKJMnU" frameborder="0" allow="autoplay; encrypted-media"></iframe><br>

		<center><my   style="float:left;font-size: 23px; width: 40%; font-style:bold; padding: 30px;background-color: brown">Since 2013<br><br> ©  2023 by Hair & There. Proudly created for You</my></center>
	
		
		
	<button class="open-button" onclick="openForm()">Help Desk</button>
	<div class="form-popup" id="myForm">
  	<form action="mailto:prabhusagar1305@gmail.com" method="post" enctype="text/plain" action="/action_page.php" class="form-container">
    <h1>HELP</h1>
    <p>Do You have any Questions?</p>

    <p><input type="text" placeholder="Name" required name="Name" style="width: 200px; border-radius: 5px;,opacity: 0.8;"></p>
    <p><input type="text" placeholder="Email" required name="Email" style="width: 200px; border-radius: 5px;,opacity: 0.8;"></p>
    <p><input type="text" placeholder="Message" required name="Message" style="width: 200px; border-radius: 5px;,opacity: 0.8; height: 80px;" ></p>
            
    <button type="submit" class="btn">Send</button>
    <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
  </form>
		
	</div><br><br><br>
	
		 
<script>document.createElement("my")</script>
<div class="footer">
	<a href="homepage.php">Home</a>

 </div>	

 <script>
function openForm() {
    document.getElementById("myForm").style.display = "block";
}

function closeForm() {
    document.getElementById("myForm").style.display = "none";
}

function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}


</script> 
</body>
<head>


</html>