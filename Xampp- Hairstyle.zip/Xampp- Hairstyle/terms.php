<!DOCTYPE html>
<html>
<head>
	<title>Terms & Conditons</title>
</head>
<body style="background: #b6bfc8">

<h1  style="font-size: 40px;font-family: sans-serif;color: white">TERMS AND CONDITIONS .</h1>
<br><br><br>

<my style="font-size: 30px">1.Registration Types</my><br>
<my style="font-size:20px">- You agree to pay in full the fee that is applicable to your registration category. For example, current full-time students possessing valid student identification are entitled to register at the student rate.</my><br><br>

<my style="font-style:bold;font-size: 30px">2.Registration Confirmation & Updates</my><br>
<my style="font-size:20px"> -  You will receive your registration confirmation and payment receipt by email. Please ensure that your email address is entered correctly in your account on the registration site.</my><br><br>

 <my style="font-size: 30px">3.Cancellations & Refunds</my><br>
 <my style="font-size:20px">-  If you cancel by the aforementioned notification date, your registration fees (including main conference registration, education forum registration.</my><br><br>

<my style="font-size: 30px">5.Disclaimer</my><br>

<my style="font-size:20px">- SOTA is not responsible for errors or omissions.
Schedules, speakers, and program content are subject to change.
If you have further questions, please contact us.</my><br><br><br><br><br>

<center><button style="background-color:#4CAF50;border-style: none ;padding: 10px; width: 15%;font-size: 30px" > <a href="form-2.php" style="text-decoration:none;color: white;cursor: pointer;">Proceed </a></button></center> 


</body>


	<script>document.createElement("my")</script>
</html>