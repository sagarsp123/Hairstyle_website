<!DOCTYPE html>
<html>
<head>
    <title>gallery</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="animations.css">    
</head>

<body background="images/h7.jpg" style=" margin: 0px; background-size: cover;">
    <h1 style="background:#737373;padding: 20px; margin: 0px;">
    
    <a href="homepage.php"style="text-decoration: none">Home</a>
	<a href="aboutpage.php"style="text-decoration: none">About Us</a>
    <a href="form-1.php" style="text-decoration: none">Register</a>
    <a href="animations.php" style="text-decoration: none">Gallery</a>
    <a href="form-2.php" style="text-decoration: none">Style</a>
	<a href="feedback.php"style="text-decoration: none">Feedback</a>
    <a href="Contact.php"style="text-decoration: none">Contact Us</a>
	
    <a href="https://www.facebook.com/"><i class="fa fa-facebook" onMouseOver="this.style.color='#0000cc'" onMouseOut="this.style.color='white'" style="color: white;float: right;padding: 15px;"></i></a>

    <a href="https://www.instagram.com/"><i class="fa fa-instagram" onMouseOver="this.style.color='pink'" onMouseOut="this.style.color='white'" style="float:right;color: white; padding: 15px;"></i></a>
    
    <a href="https://www.twitter.com/"><i class="fa fa-twitter" onMouseOver="this.style.color='#1E90FF'" onMouseOut="this.style.color='white'"style="color: white;float: right;padding: 15px;"></i></a>
    </h1><br><br>

    <h2 align="center" style="font-size: 60px;color: white; font-family:sans-serif;">   OUR  BARBER  PRESENTS .... </h2>
     
     <br><br><br>
    
    <a target="_blank" href="1.jpg">
    <img src="images/1.jpg" width="350  " height="350" style=" margin-left: 0px" > </a>
    <a target="_blank" href="2.jpg">
    <img src="images/2.jpg" width="350	" height="350" ></a>
    <a target="_blank" href="3.jpg">
    <img src="images/3.jpg" width="350	" height="350" ></a><br><br><br>
    
    <a target="_blank" href="5.jpg">
    <img src="images/5.jpg" width="350	" height="350" style="margin-left: 0px"></a>
    <a target="_blank" href="6jpg">
    <img src="images/6.jpg" width="350	" height="350" ></a>
    <a target="_blank" href="7.jpg"> 
    <img src="images/7.jpg" width="350	" height="350" ></a><br><br><br>
    
    <a target="_blank" href="9.jpg"> 
    <img src="images/9.jpg" width="350"  height="350" style="margin-left: 0px"> </a>
    <a target="_blank" href="10.jpg">
    <img src="images/10.jpg" width="350" height="350" ></a>
    <a target="_blank" href="11.jpg"> 
    <img src="images/11.jpg" width="350" height="350" ></a> <br><br><br>
    
    <a target="_blank" href="13.jpg">
    <img src="images/13.jpg" width="350" height="350" style="margin-left: 0px"> </a>
    <a target="_blank" href="14.jpg">
    <img src="images/14.jpg" width="350" height="350" > </a>
    <a target="_blank" href="16.jpg">
    <img src="images/16.jpg" width="350" height="350" ></a><br><br><br>
    
    <a target="_blank" href="18.jpg">
    <img src="images/18.jpg" width="350" height="350" > </a>
    <a target="_blank" href="19.jpg">
    <img src="images/19.jpg" width="350" height="350" ></a>
    <a target="_blank" href="25.jpg">  
    <img src="images/25.jpg" width="350" height="350" ></a><br><br><br>
    
    <a target="_blank" href="22.jpg">
    <img src="images/22.jpg" width="350" height="350" ></a>
    <a target="_blank" href="23.jpg"> 
    <img src="images/23.jpg" width="350" height="350" ></a>
    <a target="_blank" href="24.jpg"> 
    <img src="images/24.jpg" width="350" height="350" ></a><br><br><br>

<center><button style="background-color:#DEB887;border:none;font-size:30px;padding: 10px;cursor: pointer;border-radius: 15px"><a href="https://www.google.co.in/search?q=hairstyle+for+men&source=lnms&tbm=isch&sa=X&ved=0ahUKEwiJtN2z4NjdAhVVfH0KHZ5IAPIQ_AUIDigB&biw=1536&bih=754" style="text-decoration: none;color: black"> Click for More</button></center><br><br><br><br>
    

 <div class="footer">
 <center><p align="center"> GALLERY </p></center>
 </div> 

</body>

</html>