<div id="contact" style="font-size: 17px; color: black; float: left; margin: 20px;">    	
        <h1>Contact</h1>
        <p>Do You have any Questions?</p>
        <form action="mailto:prabhusagar1305@gmail.com" method="post" enctype="text/plain" >
            <p><input type="text" placeholder="Name" required name="Name" style="width: 200px; border-radius: 5px;,opacity: 0.8;"></p>
            <p><input type="text" placeholder="Email" required name="Email" style="width: 200px; border-radius: 5px;,opacity: 0.8;"></p>
            <p><input type="text" placeholder="Message" required name="Message" style="width: 200px; border-radius: 5px;,opacity: 0.8; height: 80px;" ></p>
            <span><button type="submit" style="border-radius: 10px;background-color: white; color: black; ">Send</button></span>
            <span><button type="reset" value="Reset" style="border-radius: 10px;background-color: white; color: black; ">Reset</button></span>
        <br><br><br><br>
		</form>
</div>    
