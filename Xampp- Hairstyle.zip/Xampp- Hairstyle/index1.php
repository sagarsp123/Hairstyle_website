<html>
<body>

<form id="requirement">
Your dfdsFace Shape: <input type="text" name="faceshape"><br>
Your Skin Tone: <input type="text" name="skintone"><br>
Hair length you need: <input type="text" name="hairlength"><br>
Hair to be coloured to: <input type="text" name="haircolor"><br>
<input type="" id="submit">
</form>

</body>
</html> 

