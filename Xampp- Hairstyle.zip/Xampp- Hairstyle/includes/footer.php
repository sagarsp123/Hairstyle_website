<div class="footer">
 <center><p align="center"> Home </p></center>
 </div>	
 </style>
</body>
	<center><p align="center"  style="font-size: 23px; width: 70%; font-style:bold; padding: 20px;background-color: brown">Since 2013<br><br> ©  2023 by Hair & There. Proudly created for You</p></center><br><br><br>

 <style>
	.footer {
   left: 0;
   bottom: 0;
   position: fixed;
   width: 15%;
   padding: 5px;
   background-color: black;
   color: white;
   text-align: center;
}
</style>