<!DOCTYPE html>

<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Home</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body background="h6.jpg" style="margin: 0px;background-size: cover;">

  <h1 style="background: #512415;padding: 20px; margin: 0px;">
  
  <div class="navbar">
  <a href="homepage.php" style="text-decoration: none">Home</a>
  <a href="aboutpage.php"style="text-decoration: none">About Us</a>

  <div class="dropdown">
      <button class="dropbtn"> Register
        <i class="fa fa-caret-down"></i>
      </button>
      <div class="dropdown-content">
        <a href="form-1.php">Register</a>
        <a href="login.php">Log In</a>
        
        
      </div>
  </div>
    
 
  <a href="animations.php" style="text-decoration: none">Gallery</a>
  <a href="form-2.php" style="text-decoration: none">Style</a>
  <a href="feedback.php"style="text-decoration: none">Feedback</a>
  <a href="Contact.php"style="text-decoration: none">Contact</a>
  
    <a href="https://www.facebook.com/"><i class="fa fa-facebook" onMouseOver="this.style.color='#0000cc'" onMouseOut="this.style.color='white'" style="color: white;float: right;padding: 15px;"></i></a>

  <a href="https://www.instagram.com/"  ><i class="fa fa-instagram"  onMouseOver="this.style.color='pink'" onMouseOut="this.style.color='white'" style="float:right;color: white; padding: 15px;"></i></a>
  
  <a href="https://www.twitter.com/"><i class="fa fa-twitter" onMouseOver="this.style.color='#1E90FF'" onMouseOut="this.style.color='white'" style="color: white;float: right;padding: 15px;"></i></a>

  
     
  
  
  </h1><br><br>

  <img   src="h1.jpg" width="300" style="opacity: 0.6s" height="300" align="sleft">   
  <center><h2  style="color: white; font-size: 45px; font-family: sans-serif;">- GENTLEMEN'S -</h2></center>
  <center><h2 style="color:white; font-size: 60px;font-family: sans-Serif;"> HAIR STYLE ON POINT</h2></center>
  <hr style="width: 70%"><br><br><br>

  

  <article style="padding: 20px;color: grey;font-size: 20px">
    <h2 align="center" style="font-size: 60px;color: #FF7F50;font-style: bold;font-family: sans-serif;">OUR STORY</h2>
    <p style="color: white;font-size: 30px;font-family:serif ; background:#daa671;padding: 10px;color: black">
      " I think dress, hairstyle and make-up are the crucial factors in projecting an attractive persona and give one the chance to enhance one's best physical features"<br> -Vivienne Westwood<br><br>In today's competitive world, a proper appearance is important - both in professional and casual life. Our hair is a key component of our appearance. Hence, people of all ages and genders try to style their hair in a way that suits them best. Yet, this opportunity to improve stays locked behind expensive salons and barbershops. <br><br>This is a problem modern technology can solve. Using a database of hairstyles, we characterize each hairstyle into different categories. We three team members strive to create a website than can suggest hairstyles that are just right for you. Each an everu individualycan have their preferences attended to using just a computer screen. From the comfort of your home, you can consider different hairstyles and interesting appearances. Hence, we three students have set out to create such a website for this exciting application.<br><br>

    </p>
      
    </article>
    <hr style="width: 70%"><br>

    <br><br><br><br>

    <div class="box">
    <div class="maincontainer">

    <div class="thecard">

    <div class="thefront">

  <img   src="images/straight.jpg" width="250" style="opacity: 1.5s" height="320" align="left">   
  <div class="bottom">Straight Hair</div>


    </div>

    <div class="theback"><br>Straight Hair

    <div class="centered">Guys with straight hair are<br>truly lucky–almost all the <br>best, stylish men’s hair <br>styles work well with thick,<br> straight hair. </div>

    </div>

    </div>  


    </div>

    <div class="maincontainer">

    <div class="thecard">

    <div class="thefront">

  <img   src="images/curly.jpg" width="250" style="opacity: 1.5s" height="320" align="left">    
  <div class="bottom">Curly Hair</div>


    </div>

    <div class="theback"><br>Curly Hair

    <div class="centered">Most men think that they are<br>fighting a lost battle when<br>styling their curly mane.<br>
 However,we know that when<br>cared for and styled<br>appropriately,curly hair<br>makes for a striking feature.<br> </div>

    </div>

    </div>  


    </div>

    <div class="maincontainer">

    <div class="thecard">

    <div class="thefront">

  <img   src="images/spiky.jpg" width="250" style="opacity: 1.5s" height="320" align="left">    
  <div class="bottom">Spiky Hair</div>


    </div>

    <div class="theback"><br>Spiky Hair

    <div class="centered">Spiky hair has long been a<br> fashionable look for men,<br>and while the rock-hard <br>points of the past are gone,<br> this sharp style remains an<br> excellent option for gents.</div>

    </div>

    </div>  


    </div>
  
    <div class="maincontainer">

    <div class="thecard">

    <div class="thefront">

  <img   src="images/scissor.jpg" width="250" style="opacity: 1.5s" height="320" align="left">    
  <div class="bottom">Scissor cut Hair</div>


    </div>

    <div class="theback"><br>Scissor cut Hair

    <div class="centered"> Hair-cutting shears have<br> specific blade angles ideal<br> for cutting hair. </div>

    </div>

    </div>  


    </div>
    <div class="maincontainer">

    <div class="thecard">

    <div class="thefront">

  <img   src="images/slick.jpg" width="250" style="opacity: 1.5s" height="320" align="left">    
  <div class="bottom">Slick Back Hair</div>


    </div>

    <div class="theback"><br>Slick Back Hair

    <div class="centered"> Want to look formal with<br> long hair?Then the slick back<br> style is for you.<br> Use a wet product like<br> pomade and a comb to<br> pull your hair back,<br> keeping it neat and tidy<br> for any fancy occasion.</div>

    </div>

    </div>  


    </div>
    
    <div class="maincontainer">

    <div class="thecard">

    <div class="thefront">

  <img   src="images/ponytail.jpg" width="250" style="opacity: 1.5s" height="320" align="left">   
  <div class="bottom">Ponytail</div>


    </div>

    <div class="theback"><br>Ponytail

    <div class="centered">Ponytail hairstyles offer a<br> simple and quick<br> alternative to blow drying<br> and styling long hair. </div>

    </div>

    </div>  


    </div>
    
  </div>


    <br><br><br><br>
    <div class="container" align="right" >
    <my style="padding:20px;font-size: 30px;font-family: sans-serif;">About Us </my> <br>

    <br><iframe style="float: right;" width="600" height="300" src="https://www.youtube.com/embed/LDAT9NKJMnU" frameborder="0" allow="autoplay; encrypted-media"></iframe><br>

    <center><my   style="float:left;font-size: 23px; width: 40%; font-style:bold; padding: 30px;background-color: brown">Since 2013<br><br> ©  2023 by Hair & There. Proudly created for You</my></center>
  
    
    
  <button class="open-button" onclick="openForm()">Help Desk</button>
  <div class="form-popup" id="myForm">
    <form action="mailto:prabhusagar1305@gmail.com" method="post" enctype="text/plain" action="/action_page.php" class="form-container">
    <h1>HELP</h1>
    <p>Do You have any Questions?</p>

    <p><input type="text" placeholder="Name" required name="Name" style="width: 200px; border-radius: 5px;,opacity: 0.8;"></p>
    <p><input type="text" placeholder="Email" required name="Email" style="width: 200px; border-radius: 5px;,opacity: 0.8;"></p>
    <p><input type="text" placeholder="Message" required name="Message" style="width: 200px; border-radius: 5px;,opacity: 0.8; height: 80px;" ></p>
            
    <button type="submit" class="btn">Send</button>
    <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
  </form>
    
  </div><br><br><br>
  
     
<script>document.createElement("my")</script>
<div class="footer">
  <a href="homepage.php">Home</a>

 </div> 

 <script>
function openForm() {
    document.getElementById("myForm").style.display = "block";
}

function closeForm() {
    document.getElementById("myForm").style.display = "none";
}

function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}


</script> 
</body>
<head>
<style>
.header-link{
    float:right;
    font-size:5px;
    height: 25px;
    padding: 5px 5px;
    font-size:5px;
    font-weight: bold;
    
    }

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 30px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #fff;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    padding-top: 100px; /* Location of the box */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}







.open-button {
  background-color: #555;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  opacity: 0.8;
  position: fixed;
  bottom: 63px;
  left: 38px;
  width: 300px;
}

/* The popup form - hidden by default */
.form-popup {
  display: none;
  position: fixed;
  bottom: 0;
  left: 15px;
  border: 5px solid #f1f1f1;
  z-index: 9;
}

/* Add styles to the form container */
.form-container {
  max-width: 300px;
  padding: 10px;
  background-color: white;
}

/* Full-width input fields */
.form-container input[type=text], .form-container input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  border: none;
  background: #f1f1f1;
}

/* When the inputs get focus, do something */
.form-container input[type=text]:focus, .form-container input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Set a style for the submit/login button */
.form-container .btn {
  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
  margin-bottom:10px;
  opacity: 0.8;
}

/* Add a red background color to the cancel button */
.form-container .cancel {
  background-color: red;
}

/* Add some hover effects to buttons */
.form-container .btn:hover, .open-button:hover {
  opacity: 1;
}

img {
    opacity: 0.8;
    filter: alpha(opacity=50); /* For IE8 and earlier */
}

img:hover {
    opacity: 1.0;
    filter: alpha(opacity=100); /* For IE8 and earlier */
}
.centered {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}


.bottom {
    position: absolute;
    bottom: 88%;
    left: 50%;
    transform: translate(-50%, -50%);
}

.box{
  height: 320px;
  
  overflow-x: scroll;
  overflow-y: hidden;
  white-space: nowrap;
}

.box::-webkit-scrollbar{
  display:none;
}
.maincontainer{
  display: inline-block;
  margin-left: 60px;
  position:relative;
  width:250px;
  height: 320px;
  border-radius: 20px;
}

.thecard{

  position:absolute;
  width:100%;
  height:100%;
  transform-style: preserve-3d;
  transition: all 0.5s ease;
border-radius: 20px;
}

.thecard:hover{
  transform:rotateY(180deg);
}
.thefront{

  position:absolute;
  width:100%;
  height:100%;
  backface-visibility: hidden;
  background:#ffc728;
  color:black;
  text-align: center;
  font-family: "Comic Sans MS", cursive, sans-serif;
  border-radius: 20px;
  font-size: 20px;
  font-weight: bold;


}


.theback{

  position:absolute;
  width:100%;
  height:100%;
  backface-visibility: hidden;
  background:#5fcf80;
  color:#fff;
  text-align: center;
  font-family: 'zilla slab',sans-serif;
  border-radius: 20px;
  font-size: 18px;
  font-weight: bold;
  transform: rotateY(180deg);

}

  .footer {
   left: 0;
   bottom: 0;
   position: fixed;
   width: 15%;
   padding: 5px;
   background-color: black;
   color: white;
   text-align: center;
}
  input[type=submit]{
    width: 20%;
    display: inline;
    font-size: 15px;
    background:black;
    margin: 0px;
    color: white;
    border: none;
    margin: 8px;
    padding: 14px;
    cursor: pointer;}

  .navbar a:hover{color:#b35b32}
  .navbar a{
    
    font-size:20px;
    padding: 5px;
    color: white;
    padding: 20px 40px;
    margin: 0px;
    cursor: pointer;
  }

  .container {
    position: absolute;
    
    margin: 10px;
    width: 95%;
    height: 75%;
    padding: 20px;
    background-color:#daa671;
    }

@media only screen and (max-width: 300px) {
  .text {font-size: 11px}
}

.dropdown {
    float: right;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 20px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}
.topnav a:hover, .dropdown:hover .dropbtn {
  background-color: #555;
  color: white;
}
.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {
    background-color: #ddd;
}

.dropdown:hover .dropdown-content {
    display: block;
}


@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
  }
}



</style>

</html>